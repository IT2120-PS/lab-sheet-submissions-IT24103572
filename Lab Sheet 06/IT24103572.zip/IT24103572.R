setwd("C:\\Users\\mellow\\OneDrive\\Desktop\\IT24103572")

#Question 1 - i
#Binomial distribution

#Question 1 - ii
# Probability at least 47 pass
#n=50 and p=0.85
pbinom(47, 50, 0.85, lower.tail = FALSE)

#Question 2 - i
#Random variable X: Number of customer calls received in one hour

#Question 2 - ii
#Poisson distribution 

#Question 2 - iii
#P(X = 15) ,λ = 12
dpois(15, 12)


