setwd("C:\\Users\\IT24103572\\Desktop\\IT24103572")
branch_data <- read.csv("Exercise.txt", header = TRUE, stringsAsFactors = FALSE)


str(branch_data)


boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        outline = TRUE,
        outpch =8,
        horizontal = TRUE)


summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)


find_outliers <- function(x) {
  q <- quantile(x, probs = c(0.25, 0.75), na.rm = TRUE)
  iqr <- q[2] - q[1]
  lower <- q[1] - 1.5 * iqr
  upper <- q[2] + 1.5 * iqr
  x[x < lower | x > upper]
}
find_outliers(branch_data$Years_X3)

find_modes <- function(x) {
  ux <- unique(x)
  freqs <- tabulate(match(x, ux))
  ux[freqs == max(freqs)]
}
find_modes(branch_data$Years_X3)
